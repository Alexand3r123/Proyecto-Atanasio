<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="css/stylos.css">
<title>Error 404 - Página no encontrada</title>
</head>

<body>
<div class="error-page">
		<h1>Oops! Error 404</h1>
		<p>Lo sentimos, la página que estás buscando no se encuentra disponible.</p>
		<a href="invi.php">Volver al inicio</a>
	</div>
</body>
</html>