<?php


$conn = mysqli_connect('localhost','root','','2013escuela');
session_start();

?>